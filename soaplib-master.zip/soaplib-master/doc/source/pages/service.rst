Service
=======

The service module provides the methods and classes for producing the soap service


.. automodule:: soaplib.core.service
    :members:
    :undoc-members:
    :inherited-members: